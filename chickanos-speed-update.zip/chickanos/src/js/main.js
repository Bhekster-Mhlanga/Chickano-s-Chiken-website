import { initNav } from "./nav.js";
import { initTicker } from "./ticker.js";
import { initReveal } from "./reveal.js";
import { initReviews } from "./reviews.js";
import { initCart } from "./cart.js";
import { initMenu } from "./menu.js";
import { initFind } from "./find.js";
import { initContact } from "./contact.js";
import { initFranchising } from "./franchising.js";

initNav();
initTicker();
initReveal();
initReviews();
initCart();
initMenu();
initFind();
initContact();
initFranchising();
